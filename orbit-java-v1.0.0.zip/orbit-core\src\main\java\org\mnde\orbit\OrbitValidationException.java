package org.mnde.orbit;

public final class OrbitValidationException extends RuntimeException {

    public OrbitValidationException(String message) {
        super(message);
    }
}
